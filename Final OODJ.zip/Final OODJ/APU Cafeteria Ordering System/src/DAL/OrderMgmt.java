
package DAL;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;


public class OrderMgmt extends Menu {
    
    static String[][] orderedItem;
    String paymentMethod;
    String paymentAmount;
    
    public OrderMgmt(){
    }
    
    public void setOrderedItem (String[][] orderedItem){ // after customer add a item set the item in cart.txt to orderedItem
        OrderMgmt.orderedItem = orderedItem;
    }
    

    
    public void setPaymentDetails(String paymentMethod, String paymentAmount){
        this.paymentMethod = paymentMethod;
        this.paymentAmount = paymentAmount;
    }
    
  
    //for test
    File orderFile = new File("Orderfood.txt");


    public void write_Order_to_OrderFIle(){
        String orderFood= "";
        for (String[] orderedItem1 : orderedItem) {
            orderFood = orderFood + orderedItem1[0] + " x " + orderedItem1[1] + ",";
        }
        String orderId = generate_Order_Id();
        try {
            try (PrintWriter pw = new PrintWriter(new FileWriter(orderFile,true))) {
                pw.write(orderId+":"+customerName+":"+customerTpNO+":"+orderFood+":"+ paymentMethod+":"+paymentAmount+"\n");
            }
        } catch (IOException e) {
            System.out.println(e);
        }
    }
    
   
    
    public String generate_Order_Id(){
     try {
             BufferedReader rd = new BufferedReader(new FileReader(orderFile));
             ArrayList<String> allOrder = new ArrayList<>();
             String line;
        while (( line = rd.readLine())!= null) {
            allOrder.add(line);
        }
         String orderID = "O"+ Integer.toString(allOrder.size()+1);
         new Feedback().setOrderID(orderID);
         return orderID;
        } 
       catch (IOException e) {
            System.out.println(e);
        }
        return null;
    }
   
}
