
package DAL;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JList;


public class Menu {

    String [][] menu;
    static  protected String customerName;
    static  protected String customerTpNO;
    
       

  
   File menuFile = new File("Menu.txt");
    
    
    public void Menu() {
        menu = load_Menu_Data();    
    }
    
    public void setCustomerDetails(String cusName, String cusTpNo){
        customerName = cusName;
        customerTpNO = cusTpNo;
    
    }
    
    String[][] load_Menu_Data (){
        try {
            ArrayList<String> menuAL;
            try (BufferedReader rd = new BufferedReader(new FileReader(menuFile))) {
                menuAL = new ArrayList<>();
                String line;
                while (( line = rd.readLine())!= null) {
                    menuAL.add(line);
                }   }
        
        String[] menuArray = menuAL.toArray(String[]::new);
        String[][] menuArray2D = new String[menuArray.length][3];
        for(int i=0; i< menuArray.length ; i++){
                 System.arraycopy(menuArray[i].split(":"), 0, menuArray2D[i], 0, 3);
        }
        return menuArray2D;  
        } catch (IOException e) {
            System.out.println(e);
        }
        return null;
    }
    
    public void display_Menu_To_List(JList localFoodList, JList WesternFoodList,JList BeverageList,JList priceLocalFoodList,JList priceWesternList,JList priceBeverageList){
        menu = load_Menu_Data();
        DefaultListModel temp1 = new DefaultListModel();
        localFoodList.setModel(temp1);
        for (String[] menu1 : menu) {
            if ("Local".equals(menu1[0])) {
                temp1.addElement(menu1[1]);
            }
        }
    
        DefaultListModel temp3 = new DefaultListModel();
        WesternFoodList.setModel(temp3);
        for (String[] menu1 : menu) {
            if ("Western Food".equals(menu1[0])) {
                temp3.addElement(menu1[1]);
            }
        }
        
        DefaultListModel temp2 = new DefaultListModel();
        BeverageList.setModel(temp2);
        for (String[] menu1 : menu) {
            if ("Beverage".equals(menu1[0])) {
                temp2.addElement(menu1[1]);
            }
        }
        DefaultListModel price1 = new DefaultListModel();
        priceLocalFoodList.setModel(price1);
        for (String[] menu1 : menu) {
            if ("Local".equals(menu1[0])) {
                price1.addElement("RM" + menu1[2]);
            }
        }
        DefaultListModel price2 = new DefaultListModel();
        priceWesternList.setModel(price2);
        for (String[] menu1 : menu) {
            if ("Western Food".equals(menu1[0])) {
                price2.addElement("RM" + menu1[2]);
            }
        }
        DefaultListModel price3 = new DefaultListModel();
        priceBeverageList.setModel(price3);
        for (String[] menu1 : menu) {
            if ("Beverage".equals(menu1[0])) {
                price3.addElement("RM" + menu1[2]);
            }
        }
    }
}
